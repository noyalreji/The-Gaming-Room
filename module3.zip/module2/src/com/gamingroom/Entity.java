package com.gamingroom;

public abstract class Entity {
    private long id; // Identifier of the entity
    private String name; // Name of the entity

    public Entity(long id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * Retrieves the identifier of the entity.
     *
     * @return the identifier of the entity
     */
    public long getId() {
        return id;
    }

    /**
     * Retrieves the name of the entity.
     *
     * @return the name of the entity
     */
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Entity{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}
