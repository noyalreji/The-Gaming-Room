package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A class to represent a game entity.
 */
public class Game extends Entity {
    private List<Player> players = new ArrayList<>(); // List to store players in the game
    private List<Team> teams = new ArrayList<>(); // List to store teams in the game

    /**
     * Constructor with an identifier and name.
     */
    public Game(long id, String name) {
        super(id, name);
    }

    /**
     * Adds a player to the game.
     *
     * @param player the player to add
     */
    public void addPlayer(Player player) {
        players.add(player);
    }

    /**
     * Adds a team to the game.
     *
     * @param team the team to add
     */
    public void addTeam(Team team) {
        teams.add(team);
    }

    /**
     * Retrieves all players in the game.
     *
     * @return a list of players in the game
     */
    public List<Player> getPlayers() {
        return players;
    }

    /**
     * Retrieves all teams in the game.
     *
     * @return a list of teams in the game
     */
    public List<Team> getTeams() {
        return teams;
    }

    @Override
    public String toString() {
        return "Game [id=" + getId() + ", name=" + getName() + "]";
    }
}
