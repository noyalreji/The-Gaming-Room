package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * The singleton pattern ensures that there is only one instance of the GameService class present in memory at any given time.
 * This pattern is beneficial when you want to establish a single, centralized access point to the GameService functionality
 * throughout the application. In the context of this application, the GameService plays a crucial role in
 * managing the game engine's operations, including adding new games, retrieving existing games, and maintaining the list of active games.
 * By implementing the singleton pattern, we enforce the presence of a single, globally accessible GameService instance.
 * This allows all components of the application to consistently interact with the same GameService object, ensuring unified
 * game management and avoiding conflicts or inconsistencies that could arise from multiple instances.
 *
 * Using the singleton pattern in this way provides a standardized and reliable approach to handling game-related operations, simplifying the codebase and promoting efficient coordination among different parts of the application.
 */
public class GameService {

    /**
     * A list of the active games
     */
    private List<Game> games = new ArrayList<>();

    /**
     * Holds the next game identifier
     */
    private long nextGameId = 1;

    /**
     * Holds the next team identifier
     */
    private long nextTeamId = 1;

    /**
     * Holds the next player identifier
     */
    private long nextPlayerId = 1;

    // A singleton instance
    private static GameService instance;

    // Private constructor to prevent instantiation outside this class
    private GameService() {
    }

    /**
     * Returns the singleton instance of the GameService
     *
     * @return singleton instance of the GameService
     */
    public static synchronized GameService getInstance() {
        if (instance == null) {
            instance = new GameService();
        }
        return instance;
    }

    /**
     * Construct a new game instance
     *
     * @param name the unique name of the game
     * @return the game instance (new or existing)
     */
    public Game addGame(String name) {
        Game game = getGameByName(name);

        if (game == null) {
            game = new Game(nextGameId++, name);
            games.add(game);
        }

        return game;
    }

    /**
     * Returns the game instance at the specified index.
     *
     * @param index index position in the list to return
     * @return requested game instance
     */
    public Game getGame(int index) {
        return games.get(index);
    }

    /**
     * Returns the game instance with the specified id.
     *
     * @param id unique identifier of game to search for
     * @return requested game instance, or null if not found
     */
    public Game getGame(long id) {
        for (Game game : games) {
            if (game.getId() == id) {
                return game;
            }
        }
        return null;
    }

    /**
     * Returns the game instance with the specified name.
     *
     * @param name unique name of game to search for
     * @return requested game instance, or null if not found
     */
    public Game getGame(String name) {
        return getGameByName(name);
    }

    /**
     * Returns the number of games currently active
     *
     * @return the number of games currently active
     */
    public int getGameCount() {
        return games.size();
    }

    /**
     * Retrieves the game instance with the specified name.
     *
     * @param name unique name of game to search for
     * @return requested game instance, or null if not found
     */
    private Game getGameByName(String name) {
        for (Game game : games) {
            if (game.getName().equals(name)) {
                return game;
            }
        }
        return null;
    }

    /**
     * Adds a new player to the specified game.
     *
     * @param gameId     the id of the game to add the player to
     * @param playerName the name of the player
     * @return the created player instance, or null if the game was not found or the player name is not unique
     */
    public Player addPlayer(long gameId, String playerName) {
        Game game = getGame(gameId);
        if (game != null) {
            if (!isPlayerNameUnique(playerName, game)) {
                return null; // Player name is not unique
            }

            Player player = new Player(nextPlayerId++, playerName);
            game.addPlayer(player);
            return player;
        }
        return null; // Game not found
    }

    /**
     * Adds a new team to the specified game.
     *
     * @param gameId   the id of the game to add the team to
     * @param teamName the name of the team
     * @return the created team instance, or null if the game was not found or the team name is not unique
     */
    public Team addTeam(long gameId, String teamName) {
        Game game = getGame(gameId);
        if (game != null) {
            if (!isTeamNameUnique(game, teamName)) {
                return null; // Team name is not unique
            }

            Team team = new Team(nextTeamId++, teamName);
            game.addTeam(team);
            return team;
        }
        return null; // Game not found
    }

    /**
     * Checks if the player name is unique within the specified game.
     *
     * @param playerName the name of the player to check
     * @param game       the game to check for player name uniqueness
     * @return true if the player name is unique, false otherwise
     */
    private boolean isPlayerNameUnique(String playerName, Game game) {
        for (Player player : game.getPlayers()) {
            if (player.getName().equals(playerName)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Checks if the team name is unique within the specified game.
     *
     * @param game     the game to check for team name uniqueness
     * @param teamName the name of the team to check
     * @return true if the team name is unique, false otherwise
     */
    private boolean isTeamNameUnique(Game game, String teamName) {
        for (Team team : game.getTeams()) {
            if (team.getName().equals(teamName)) {
                return false;
            }
        }
        return true;
    }
}
